package xyz.luan.audioplayers.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
